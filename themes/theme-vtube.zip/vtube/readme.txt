== VTube ==

== Translations ==
Contribute to translations: https://github.com/wp-script/products-translations
* Italian (0%): 0/259 lines translated
* Russian (0%): 0/259 lines translated
* English (100%): 259/259 lines translated
* Portuguese (0%): 0/259 lines translated
* Spanish (0%): 0/259 lines translated
* French (0%): 0/259 lines translated
* German (0%): 0/259 lines translated
* Chinese (0%): 0/259 lines translated

== Changelog ==
= 1.0.5 = 2021-05-25
* Fixed: Youtube videos can now be played

= 1.0.4 = 2021-05-11
* Fixed: Ad slot under video player

= 1.0.3 = 2021-05-07
* Fixed: Iframe replacement in video url

= 1.0.2 = 2020-06-10
* Added: New option Google Analytics in the Scripts section to paste Google Analytics tracking code
* Added: New option Meta Verification in the Scripts section to paste domain meta verification code
* Added: New option Other scripts in the Scripts section to paste scripts like popunder for example
* Added: New option section Scripts
* Added: Favicon upload file option in the Logo & Favicon customizer section
* Updated: Logotype section becomes Logo & Favicon in the customizer
* Fixed: CSS loading issue

= 1.0.1 = 2020-02-28
* Updated: Under video player advertising slot removed (does not exist on Xvideos.com)
* Fixed: Mobile menu displaying
* Fixed: Minor bugs

= 1.0.0 = 2020-02-27
* Added: Initial release

