<div class="under-video-block videos-list">    
    <?php
    $related = get_posts( array(
        'category__in' => wp_get_post_categories($post->ID),
        'numberposts' => xbox_get_field_value( 'wpst-options', 'related-videos-number' ),
        'post__not_in' => array($post->ID)
        ) 
    ); ?>
    <?php if ($related) : ?>
        <h2><?php esc_html_e( 'Related videos', 'wpst' ); ?></h2>
        <?php
            if( $related ) foreach( $related as $post ) {
                setup_postdata($post);
                get_template_part( 'template-parts/loop', get_post_format() ? : 'video' );
            }
        ?>
        <?php wp_reset_postdata();
    endif; ?>
    <?php $category = get_the_category($post->ID); ?>
    <div class="clear"></div>
    <div class="show-more-related">
        <a class="button large" href="<?php echo get_category_link($category[0]->term_id); ?>"><?php esc_html_e('Show more related videos', 'wpst'); ?></a>
    </div>
</div>
<div class="clear"></div>