== KingTube ==

== Changelog ==
= 1.2.6 = 2021-05-25
* Fixed: Youtube videos can now be played
* Fixed: Iframe replacement in video url
* Fixed: Extra double quote in pagination

= 1.2.5 = 2020-12-17
* Fixed: Read more visual bug on video pages

= 1.2.4 = 2019-06-18
* Added: New option in the Tools section to create widgets like KingTube homepage demo

= 1.2.3 = 2019-06-14
* Fixed: LiveJasmin embed player responsive displaying
* Fixed: Photo gallery on blog posts and pages displaying
* Fixed: Warning count() Parameter must be an array or an object that implements Countable warnings with php 7.3

= 1.2.2 = 2019-04-29
* Fixed: Close ad button when no ad displaying issue
* Fixed: PHP Fatal error Can't use function return value in write context with some old PHP versions

= 1.2.1 = 2019-04-26
* Fixed: Number of categories per page option
* Fixed: In-video banner display when WPS player plugin activated

= 1.2.0 = 2019-04-24
* Added: Option to display or not your logo in the footer
* Added: Alt tag in the footer logo image
* Added: New option to display Title and Description at the top or the bottom of the homepage
* Added: New option to display H1 title on the homepage to improve SEO
* Added: New option to display the tag description at the top or the bottom of the tag page
* Updated: Possibility to display photos and blog categories and tags directly from the menu items selector
* Updated: Login link in the comment section when users have to be logged to post a comment
* Fixed: Thumbnails rotation (the first image was bypass, the latest was displayed two times)
* Fixed: Category description displaying
* Fixed: Uncaught (in promise) DOMException console error when hovering videos trailers too fast in Google Chrome

= 1.1.9 = 2019-01-18
* Added: 4k resolution field in Video Information metabox
* Updated: New WordPress editor for Blog and Photos posts

= 1.1.8 = 2018-12-18
* Fixed: Actors taxonomy not showed in video post admin since WordPress 5 release

= 1.1.7 = 2018-12-05
* Added: Option in Membership section to display or not the admin bar for logged in users
* Added: Option in Mobile section (Code tab) to add scripts only for mobile device
* Added: New Code tab option in Mobile section
* Updated: get_stylesheet_directory_uri() function replaced by get_template_directory_uri() for child theme compatibility
* Fixed: Thumb link didn't work on mobile in some cases
* Fixed: Before play advertising displaying when embed code was added directly in the description field
* Fixed: Video player position when embed code in the description
* Fixed: Minor bugs

= 1.1.6 = 2018-11-15
* Added: Views count over thumb
* Updated: Menu section position on mobile device
* Fixed: Other images than gallery images, like banners for example, opened in lightbox in photos gallery pages
* Fixed: Fluid Player on pause ads that didn't work in JavaScript
* Fixed: Fluid Player on start ads that didn't close when playing the video
* Fixed: Fluid Player console error Cannot read property 'setAttribute' of null
* Fixed: Minor bugs

= 1.1.5 = 2018-11-06
* Added: Thumbnail image in RSS feed
* Fixed: JavaScript versioning

= 1.1.4 = 2018-11-02
* Fixed: In-video advertising location size in mobile version
* Fixed: YouTube embed player generation from YouTube video URL

= 1.1.3 = 2018-10-31
* Fixed: Close over video advertising issue with iframe players

= 1.1.2 = 2018-10-30
* Added: Mid-roll in-stream ad with timer in the Video Player theme option section. It plays a video advertising in the middle of the video automatically (you can set a timer when you want the advertising starts. For example 50%.)
* Added: Pre-roll in-stream ad in the Video Player theme option section. It plays a video advertising with a skip ad button at the beginning
* Added: Close and play button at the bottom of the banners over the video which automatically plays the video
* Added: On pause advertising zone 1 & 2 in the Video Player theme option section. These banners are displayed over the video player when the user pauses the video
* Added: Before play advertising zone 1 & 2 in the Video Player theme option section. These banners are displayed over the video player when the user arrives on the page
* Added: New logo options in the Video Player theme option section (with logo position, margin, opacity and grayscale features)
* Added: Playback Speed option in the Video Player theme option section (Add a new control bar option to allow users to play video at different speeds)
* Added: New Autoplay option in the Video Player theme option section (The video plays automatically)
* Added: New theme option menu named Video Player
* Added: New Video Resolutions fields (240p, 360p, 480p, 720p and 1080p) in the KingTube - Video Information metabox
* Added: Listing of random videos in 404 or nothing found result search pages
* Added: HD video switch option in the KingTube - Video information metabox. Displays a HD label over the thumbnail
* Updated: VideoJS video player replaced by FluidPlayer
* Updated: Webm format compatibility for video trailers
* Updated: Text for SEO option moved to homepage only to improve SEO (the option is now in Theme Options > Content > Homepage tab)
* Fixed: Minor bugs

= 1.1.1 = 2018-10-04
* Updated: Video trailer loaded only on mouse hover to improve site speed
* Updated: Tablet devices excluded from the is_mobile conditions
* Fixed: Footer widgets display issue on mobile
* Fixed: Menu display issue on tablet

= 1.1.0 = 2018-09-28
* Added: Homepage and Footer widgets area
* Added: KingTube video block widget
* Added: Option to choose the number of columns for the widget footer area (1, 2, 3 or 4 columns)
* Added: Video trailer as preview on mouse hover in your video listing
* Added: Video trailer URL field in the KingTube - Video Information metabox
* Added: Preview of the video trailer in the KingTube - Video Information metabox
* Added: New section Blog with possibility to add articles with categories and tags
* Added: New section Photos with possibility to add photos and create galleries
* Added: Lightbox system to open photos from a gallery
* Added: Photos loading message with counter
* Added: Number of photos per gallery in archive photos page
* Added: Lazy load on photos
* Added: Easy navigation between each photos
* Updated: Posts admin menu changed to Videos (for a better understanding)

= 1.0.9 = 2018-07-18
* Fixed: 404 pages issue

= 1.0.8 = 2018-07-04
* Added: Pagination for actors list
* Added: Possibility to edit views and likes for each post in the Video Information metabox
* Added: Author, title and description video itemprop infos
* Added: Tags and actors in video submission form for users
* Added: New option to choose Aspect ratios of thumbnails (16/9 or 4/3)
* Added: New option to choose Main thumbnail quality (basic, normal or fine)
* Added: New option to choose the position of category description (top or bottom of the page)
* Added: New option to set the same link for every tracking buttons in video pages
* Added: New option to choose the number of actors per page
* Fixed: Popular videos list display issue when no rated videos
* Fixed: Loading of social metas outside the video pages
* Fixed: Video information metabox displayed in page edition
* Fixed: Minor bugs

= 1.0.7 = 2018-04-25
* Added: Alt and Title tags with site name on logo image to improve SEO
* Updated: All advertising locations are now compatible with Ad Rotate plugin shortcodes
* Fixed: Social share buttons displaying on mobile devices
* Fixed: Submenu displaying on tablet devices
* Fixed: CSS version that didn't change preventing to see CSS changes when updating the theme
* Fixed: PHP Warnings generated by the Rates function
* Fixed: Preventing visitors to vote multiple times on videos

= 1.0.6 = 2018-03-27
* Fixed: Post format query issue
* Fixed: In-video width banner display issue
* Fixed: Views counting with some cache plugins

= 1.0.5 = 2018-03-20
* Added: Possibility to upload an image for actors
* Added: Integration of tags and actors fields in the frontend Video Submission form
* Added: Blog template page which allow you to create a separate blog page with standard posts
* Added: Create Blog page button in the theme options tools
* Added: Video preview for embed code section in the video information metabox (post admin)
* Added: Mobile section in the theme options with 2 tabs General and Advertising
* Added: Option to choose the number of videos per row on mobile
* Added: Option to choose the number of videos per row on desktop
* Added: Filters in tag and search page results
* Updated: Duration field changed to HH MM SS in the video information metabox (post admin)
* Updated: Actors template page with images
* Updated: Menu on desktop and mobile improvement
* Updated: Unique banner under the video player displayed on mobile devices too
* Fixed: Twitter sharing with image, title and description
* Fixed: Facebook sharing with image, title and description
* Fixed: Filters and pagination issue
* Fixed: Views and likes compatible with cache plugins
* Fixed: Sidebar displaying issue on mobile
* Fixed: Footer menu displaying
* Fixed: Minor bugs

= 1.0.4 = 2018-02-06
* Fixed: Inside video player advertising displaying issue
* Fixed: Minor bugs

= 1.0.3 = 2018-01-18
* Added: Possibility to display a unique banner under the video player for each post
* Added: Option to display or not the actors list
* Added: Translation pot file
* Added: 100% French translation
* Added: Possibility to set an image for each category
* Added: Footer menu
* Updated: Actors display in the categories / tags list under the video player
* Updated: Custom CSS option removed. Compatibility with the additional CSS option in the WordPress customizer
* Updated: Video URL preview in the Video Information metabox with YouTube, Google Drive and the most popular adult tubes
* Fixed: Close button on in-video advertising which passed behind the banners
* Fixed: Login link in the main menu even if membership disabled
* Fixed: Submit a video form redirection issue from some server
* Fixed: Minor bugs

= 1.0.2 = 2017-12-02
* Fixed: Fatal error on single video pages with some PHP versions

= 1.0.1 = 2017-12-01
* Added: Option to enable / disable thumbnails rotation
* Updated: Lazy load feature
* Fixed: Thumbnails used for rotation saving during a manual post creation
* Fixed: Minor bugs

= 1.0.0 = 2017-11-30
* Added: Initial release

