<div class="sidebar-ads">
    <?php echo wpst_render_shortcodes( xbox_get_field_value( 'wpst-options', 'sidebar-ad-desktop-1' ) ); ?>
    <?php echo wpst_render_shortcodes( xbox_get_field_value( 'wpst-options', 'sidebar-ad-desktop-2' ) ); ?>
    <?php echo wpst_render_shortcodes( xbox_get_field_value( 'wpst-options', 'sidebar-ad-desktop-3' ) ); ?>
</div>