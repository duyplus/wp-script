<?php
/**
 * @package famoustube template.
 */
// Exit if accessed directly.

defined( 'ABSPATH' ) || exit;

the_content();
