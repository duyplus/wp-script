<?php
/**
 * @package famoustubeal template.
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

the_content();
