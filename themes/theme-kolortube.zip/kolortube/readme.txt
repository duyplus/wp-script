== KolorTube ==

== Translations ==
Contribute to translations: https://github.com/wp-script/products-translations
* Italian (0%): 0/187 lines translated
* English (100%): 187/187 lines translated
* Russian (0%): 0/187 lines translated
* French (0%): 0/187 lines translated
* Portuguese (0%): 0/187 lines translated
* Spanish (0%): 0/187 lines translated
* German (0%): 0/187 lines translated
* Chinese (0%): 0/187 lines translated

== Changelog ==
= 1.1.6 = 2021-05-25
* Fixed: Youtube videos can now be played

= 1.1.5 = 2021-04-02
* Fixed: Videojs local CSS loading that could cause display issues

= 1.1.4 = 2021-03-29
* Fixed: Iframe replacement in video url on post edit page
* Fixed: Tgmpa directory for theme installation

= 1.1.3 = 2021-02-03
* Updated: load videojs from cdn
* Updated: Bump VideoJS from v7.4.1 to v7.8.4
* Updated: Bump videojs-quality-selector 1.1.2 to 1.2.4
* Updated: Remove outdated translation files
* Fixed: API wp-json/wp/v2/media endpoint doesn't return an empty array anymore

= 1.1.2 = 2020-08-21
* Fixed: Comments that were not displayed
* Fixed: Theme activation warnings

= 1.1.1 = 2020-06-29
* Added: Alt attributes on main thumbs
* Fixed: Mobile search issue on Android

= 1.1.0 = 2020-02-17
* Fixed: Nav submenu displaying issue

= 1.0.9 = 2020-02-14
* Added: New option Advertising under player to display a banner under the video player
* Added: Icons in the customizer options to facilitate navigation

= 1.0.8 = 2020-02-13
* Added: New option Google Analytics in the Scripts section to paste Google Analytics tracking code
* Added: New option Meta Verification in the Scripts section to paste domain meta verification code
* Added: New option Other scripts in the Scripts section to paste scripts like popunder for example
* Added: New option section Scripts

= 1.0.7 = 2020-02-10
* Added: Option to disable video preview on thumb mouse hover
* Added: Option to disable thumbnails rotation on thumb mouse hover
* Fixed: Missing field thumbnailUrl issue in Google indexing

= 1.0.6 = 2020-01-27
* Added: SEO option to change the show more related videos button label in single video page
* Fixed: views counter

= 1.0.5 = 2020-01-24
* Added: Pagination on categories pages
* Added: Pagination on actors pages
* Added: Ad zones on categories page template to display same ads than category pages
* Added: Default thumb when no thumb is detected in categories page template
* Added: Ads zones with new options in actors pages
* Added: Default thumb when no thumb is detected in actors page template
* Added: New button to show more related videos under related videos
* Fixed: Videos count per actor on Actors page
* Fixed: Custom permalink structure is no more reset by the theme
* Fixed: Ads before related videos are now editable
* Fixed: Ads beside player 1 can now display shortcodes
* Fixed: Ads beside player 2 can now display shortcodes
* Fixed: Ads before related videos can now display shortcodes
* Fixed: Tags page 1st letter now works with all languages
* Fixed: PHP notices

= 1.0.4 = 2020-01-03
* Fixed: Warning Cannot modify header information - headers already sent... with some server configuration
* Fixed: Theme options page is now available in the WP-Script dashboard page

= 1.0.3 = 2019-12-30
* Updated: Compatibility with ads using shortcodes
* Fixed: Ads displaying issue

= 1.0.2 = 2019-12-24
* Fixed: CSS loading issue

= 1.0.1 = 2019-12-24
* Fixed: Warning Cannot modify header information - headers already sent... error when another WP-Script theme is already installed

= 1.0.0 = 2019-12-20
* Added: Initial release

