<?php

return array(
	'Georgia',
	'Palatino Linotype',
	'Book Antiqua',
	'Palatino',
	'Times New Roman',
	'Times',
	'Arial',
	'Helvetica',
	'Arial Black',
	'Gadget',
	'Impact',
	'Charcoal',
	'Lucida Sans Unicode',
	'Lucida Grande',
	'Tahoma',
	'Geneva',
	'Trebuchet MS',
	'Helvetica',
	'Verdana',
	'Geneva',
	'Courier New',
	'Courier',
	'Lucida Console',
	'Monaco'
);