<?php
defined('_VALID') or die('Restricted Access!.com');
$sites      = array();
$sites[] = array('name' => 'analdin.com');
$sites[] = array('name' => 'boysfood.com');
$sites[] = array('name' => 'extremetube.com');
$sites[] = array('name' => 'gaytube.com');
$sites[] = array('name' => 'mylust.com');
$sites[] = array('name' => 'redtube.com');
$sites[] = array('name' => 'spankwire.com');
$sites[] = array('name' => 'tube8.com');
$sites[] = array('name' => 'xhamster.com');
$sites[] = array('name' => 'xtube.com');
$sites[] = array('name' => 'xvideos.com');
$sites[] = array('name' => 'xnxx.com');
$sites[] = array('name' => 'youjizz.com');
$sites[] = array('name' => 'porntrex.com');
?>
