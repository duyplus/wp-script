<?php
defined('_VALID') or die('Restricted Access!');

Auth::checkAdmin();

$csvformat = array('name' => '', 'format' => '');
if ( isset($_POST['add_csvformat']) ) {
    $csvformat['name']    = trim($_POST['name']);
    $csvformat['format']  = trim($_POST['format']);
	
    if ( $csvformat['name'] == '' ) {
        $errors[] = 'CSV Format name field cannot be blank!';
		$err['name'] = 1;
    } else {
        $sql        = "SELECT id FROM csv_formats WHERE name = " .$conn->qStr($csvformat['name']). " LIMIT 1";
        $conn->execute($sql);
        if ( $conn->Affected_Rows() > 0 ) {
            $errors[]   = 'CSV Format name \'' .htmlspecialchars($csvformat['name'], ENT_QUOTES, 'UTF-8'). ' is already used. Please choose another name!';
			$err['name'] = 1;
		}
    }

    if ( $csvformat['format'] == '' ) {
        $errors[] = 'CSV Format field cannot be blank!';  
		$err['format'] = 1;		
	} else {
		
		if (strpos($csvformat['format'], '|')!== FALSE) {
			$delimiter = '|';
		} elseif (strpos($csvformat['format'], ',')!== FALSE) {
			$delimiter = ',';
		} elseif (strpos($csvformat['format'], ';')!== FALSE) {
			$delimiter = ';';
		} elseif (strpos($csvformat['format'], '$')!== FALSE) {
			$delimiter = '$';
		} elseif (strpos($csvformat['format'], '%')!== FALSE) {
			$delimiter = '%';
		} elseif (strpos($csvformat['format'], '*')!== FALSE) {
			$delimiter = '*';			
		} elseif (strpos($csvformat['format'], 'TAB')!== FALSE) {
			$delimiter = 'TAB';
		} else {
			$errors[] = 'Field delimiter is missing! Allowed delimiters: <b>| , ; $ % * TAB</b>';
			$err['format'] = 1;
		}

		$parts = explode($delimiter, $csvformat['format']);
		foreach ($parts as $k => $v) {
			$value = strtolower($v);
			if (strpos($value, 'embed') !== false) {
				$format = $format.$delimiter.'embed';
			} elseif (strpos($value, 'title') !== false) {
				$format = $format.$delimiter.'title';
			} elseif (strpos($value, 'thumb') !== false) {
				$format = $format.$delimiter.'thumbs';
			} elseif (strpos($value, 'category') !== false) {
				$format = $format.$delimiter.'category';
			} elseif (strpos($value, 'channel') !== false) {
				$format = $format.$delimiter.'category';				
			} elseif (strpos($value, 'duration') !== false) {
				$format = $format.$delimiter.'duration';			
			} elseif (strpos($value, 'length') !== false) {
				$format = $format.$delimiter.'duration';
			} elseif (strpos($value, 'tag') !== false) {
				$format = $format.$delimiter.'tags';
			} elseif (strpos($value, 'description') !== false) {
				$format = $format.$delimiter.'description';				
			} else {
				$format = $format.$delimiter.'other';
			}
		}
		$format= ltrim($format, $delimiter);

		if (strpos($format, 'embed') === false) {
			$errors[] = '<b>embed</b> field is required!';
			$err['format'] = 1;
		}
		if (strpos($format, 'thumbs') === false) {
			$errors[] = '<b>thumbs</b> field is required!';
			$err['format'] = 1;			
		}
		if (strpos($format, 'title') === false) {
			$errors[] = '<b>title</b> field is required!';
			$err['format'] = 1;			
		}
		if (strpos($format, 'category') === false) {
			$errors[] = '<b>category</b> field is required!';
			$err['format'] = 1;			
		}
		if (strpos($format, 'duration') === false) {
			$errors[] = '<b>duration</b> field is required!';
			$err['format'] = 1;			
		}
	}
    if ( !$errors ) {
		$csvformat['format'] = $format;
        $sql = "INSERT INTO csv_formats (name, format) VALUES (" .$conn->qStr($csvformat['name']). ", " .$conn->qStr($csvformat['format']). ")";
        $conn->execute($sql);
		$csvformat['name']    = '';
		$csvformat['format']  = '';				
		$messages[] = 'CSV Format successfully added!';
    }
}

$query      = constructQuery();
$sql        = $query['select'];
$rs         = $conn->execute($sql);
$formats   = $rs->getrows();

function constructQuery()
{
    global $smarty;

    $query              = array();
    $query_select       = "SELECT * FROM csv_formats";
    $query_count        = "SELECT count(id) AS total_formats FROM csv_formats";
    $query_add          = NULL;
    $option_orig        = array('sort' => 'id', 'order' => 'DESC');
    $option             = ( isset($_SESSION['search_formats_option']) ) ? $_SESSION['search_formats_option'] : $option_orig;
    
    if ( isset($_POST['search_csvformats']) ) {
        $option['sort']     = trim($_POST['sort']);
        $option['order']    = trim($_POST['order']);
        
        $_SESSION['search_formats_option'] = $option;
    }

	$query_add = " ORDER BY " .$option['sort']. " " .$option['order'];    
    $query['select']    = $query_select . $query_add;
    $query['count']     = $query_count . $query_add;
    
    $smarty->assign('option', $option);
    
    return $query;
}

$plugin = 'jquery.manage-csvformats.js';

$smarty->assign('plugin', $plugin);
$smarty->assign('formats', $formats);
$smarty->assign('csvformat',$csvformat);
?>
