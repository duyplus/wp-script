<?php

defined('_VALID') or die('Restricted Access!');

require $config['BASE_DIR'].'/classes/curl.class.php';
require $config['BASE_DIR']. '/classes/image.class.php';
require_once ($config['BASE_DIR']. '/include/function_thumbs.php');
require $config['BASE_DIR'].'/classes/filter.class.php';

Auth::checkAdmin();

$width	 = (int) $config['img_max_width'];
$height	 = (int) $config['img_max_height'];
$image   = new VImageConv();
$filter	 = new VFilter();
$curl    = new VCurl();

$csv		= array('category' => '', 'username' => '', 'status' => 1, 'maxrec' => 100, 'step' => '1', 'max_thumbs' => '20', 'check_duplicate' => 1, 'order' => array());

if (isset($_POST['csv_delete'])) {  //Discard Current CSV
	
	$current_id       = $filter->get('current_id');
	$sql = "DELETE FROM csv_files WHERE id = '".$current_id."' LIMIT 1";
	$conn->execute($sql);
	$csv_file = $config['BASE_DIR'].'/media/csv/'.$current_id.'.csv';
	unlink($csv_file);
	$messages[] = "CSV file successfully discarded!";
	
} elseif (isset($_POST['csv_next_current'])) {  //Process Existing CSV

	$csv['format_id'] = $filter->get('format_id');
	$csv['id']        = $filter->get('current_id');
	$csv_file = $config['BASE_DIR'].'/media/csv/'.$csv['id'].'.csv';

	if ($csv['format_id'] == '0') {
		if (file_exists($csv_file) && is_file($csv_file)) {
			$handle = fopen($csv_file, "r");
			if ($handle) {
				$line  = fgets($handle);
				$delimiter = find_delimiter($line);
				if (!$delimiter) {
					$errors[] = 'Field delimiter is missing!<br>Please predefine CSV Format for this file here: <a href="videos.php?m=csvformats">Manage Formats</a>';
				}				
				
				$parts = explode($delimiter, $line);
				$csv['parts'] = $parts;
				$csv['total_fields'] = count($parts);
				$csv['delimiter'] = $delimiter;				
			}
		$csv['step'] = '2.1';
		}
	} else {
		$rs = $conn->execute("SELECT * FROM csv_formats WHERE id = '".$csv['format_id']."' LIMIT 1");
		if ($conn->Affected_Rows()) {
			$csv['format']    = $rs->fields['format'];		
		}		
		$csv['step'] = '3';
	}	
	
} elseif (isset($_POST['csv_next_1'])) {  //Process New CSV
	
	$csv['url']       = $filter->get('url');
	$csv['format_id'] = $filter->get('format_id');
	if ($csv['url'] == '' && ( $_FILES['csvfile_csv']['tmp_name'] == '' || !is_uploaded_file($_FILES['csvfile_csv']['tmp_name']))) {
		$errors[] = 'Please provide a CSV File!';
	} else {
		$rs = $conn->execute("SELECT * FROM csv_files LIMIT 1");
		if (!$conn->Affected_Rows()) {
			if ($csv['url'] !== '') {
				$file_url = $csv['url'];
			} else {
				$file_url = 'Local File';
			}
			$sql = "INSERT INTO csv_files (url) VALUES (".$conn->qStr($file_url).")";
			$conn->execute($sql);
			$csv['id'] = $conn->insert_Id();
			$csv_file = $config['BASE_DIR'].'/media/csv/'.$csv['id'].'.csv';
			$file_url = $config['BASE_URL'].'/media/csv/'.$csv['id'].'.csv';
			if ( $curl->saveToFile($csv['url'], $csv_file) ) {
				//count total records
				$linecount = 0;
				if (file_exists($csv_file) && is_file($csv_file)) {
					//process CSV file
					$handle = fopen($csv_file, "r");
					if ($handle) {
						while ((($line = fgets($handle)) !== false)) {
							$linecount++;
						}
					}
					fclose($handle);
				}
				$sql = "UPDATE csv_files SET total = '".$linecount."' WHERE id = '".$csv['id']."'";
				$conn->execute($sql);
			} elseif ( move_uploaded_file($_FILES['csvfile_csv']['tmp_name'], $csv_file) ) {
				//count total records
				$linecount = 0;
				if (file_exists($csv_file) && is_file($csv_file)) {
					//process CSV file
					$handle = fopen($csv_file, "r");
					if ($handle) {
						while ((($line = fgets($handle)) !== false)) {
							$linecount++;
						}
					}
					fclose($handle);
				}
				$sql = "UPDATE csv_files SET total = '".$linecount."', url = ".$conn->qStr($file_url)." WHERE id = '".$csv['id']."'";
				$conn->execute($sql);				
			} else {
				$sql = "DELETE FROM csv_files WHERE id = ".$conn->qStr($csv['id'])."";
				$conn->execute($sql);
				unlink($csv_file);
				$errors[] = 'Please provide a valid CSV File!';
			}
		} else {
			$csv['id']  	  = $rs->fields['id'];		
			$csv_file = $config['BASE_DIR'].'/media/csv/'.$csv['id'].'.csv';			
		}			
	}
	if (!$errors) {
		if ($csv['format_id'] == '0') {
			if (file_exists($csv_file) && is_file($csv_file)) {
				$handle = fopen($csv_file, "r");
				if ($handle) {
					$line  = fgets($handle);
					$delimiter = find_delimiter($line);
					if (!$delimiter) {
						$errors[] = 'Field delimiter is missing!<br>Please predefine CSV Format for this file here: <a href="videos.php?m=csvformats">Manage Formats</a>';
					}	
					$parts = explode($delimiter, $line);					
					$csv['parts'] = $parts;
					$csv['total_fields'] = count($parts);
					$csv['delimiter'] = $delimiter;
				}
				fclose($handle);
			$csv['step'] = '2.1';
			}
		} else {
			$rs = $conn->execute("SELECT * FROM csv_formats WHERE id = '".$csv['format_id']."' LIMIT 1");
			if ($conn->Affected_Rows()) {
				$csv['format']    = $rs->fields['format'];		
			}
			$csv['step'] = '3';
		}
	}
	
} elseif (isset($_POST['csv_next_2_1'])) {
	$csv['id']           = $filter->get('csv_id');
	$csv['total_fields'] = $filter->get('total_fields');
	$csv['delimiter']    = $filter->get('csv_delimiter');
	for ($i=0; $i<$csv['total_fields']; $i++) {
		$j = $i+1;
		$csv['order'][$i] = $filter->get('field_'.$j);
		$csv['parts'][]   = $_POST['field_content_'.$j];
	}
	if (!check_format($csv['order'], 'embed')) {
		$errors[] = "<b>EMBED</b> is not defined!";
	}
	if (!check_format($csv['order'], 'thumbs')) {
		$errors[] = "<b>THUMBS</b> is not defined!";
	}
	if (!check_format($csv['order'], 'title')) {
		$errors[] = "<b>TITLE</b> is not defined!";
	}
	if (!check_format($csv['order'], 'duration')) {
		$errors[] = "<b>DURATION</b> is not defined!";
	}
	if (!check_format($csv['order'], 'category')) {
		$errors[] = "<b>CATEGORY</b> is not defined!";
	}	
	//echo "<pre>";
	//print_r($csv['order']);
	//echo "</pre>";
	if (!$errors) {
		$csv['format'] = define_format($csv['order'], $csv['delimiter']);
		$csv['step'] = '2.2';
	} else {
		$csv['step'] = '2.1';
	}

} elseif (isset($_POST['csv_next_2_2'])) {
	
	$csv['id']          = $filter->get('csv_id');
	$csv['format_name'] = $filter->get('format_name');
	$csv['format']      = $filter->get('format');
	if($csv['format_name'] != '') {
		$conn->execute("SELECT id FROM csv_formats WHERE name = ".$conn->qStr($csv['format_name'])." LIMIT 1");
		if ($conn->Affected_Rows()) {
			$errors[] = 'This format name already exists! Please provide a different name!';
			$csv['step'] = '2.2';
		} else {
			$sql = "INSERT INTO csv_formats (name, format) VALUES (".$conn->qStr($csv['format_name']).", ".$conn->qStr($csv['format']).")";
			$conn->execute($sql);
			$messages[] = 'Format Successfully Saved!';
			$csv['step'] = '3';	
		}
	} else {
		$csv['step'] = '3';	
	}
	
} else {  //Check if there is a non completed CSV

}

if (isset($_POST['csv_import_start'])) {

	$csv['id']       = $filter->get('csv_id');
	$csv['format']	 = $filter->get('format');
	$csv['username'] = $filter->get('username');
	$csv['category'] = $filter->get('category');
	$csv['status']	 = $filter->get('status');
	$csv['maxrec']	 = (int) $filter->get('maxrec');
	$csv['max_thumbs']	 = (int) $filter->get('max_thumbs');
	$csv['check_duplicate'] = $filter->get('check_duplicate');
	$video_data      = array();
	$video           = array();

	if ($csv['username'] == '') {
		$errors[]	= "Username field is required!";
		$err['username'] = 1;
	} else {
		$rs = $conn->execute("SELECT UID FROM signup WHERE username = ".$conn->qStr($csv['username'])." LIMIT 1");
		if (!$conn->Affected_Rows()) {
			$errors[] = "This username doesn't exist!";
			$err['username'] = 1;
		} else {
			$user_id			= (int) $rs->fields['UID'];
		}
	}
	
	if ($category != '') {
		$csv['category'] = (int) $csv['category'];
	}
	
	if (!$errors) {
		$sql = "SELECT * FROM csv_files WHERE id = ".$conn->qStr($csv['id'])." LIMIT 1";
		$rs  = $conn->execute($sql);
		$completed	= (int) $rs->fields['completed'];
		$csv_file = $config['BASE_DIR'].'/media/csv/'.$csv['id'].'.csv';
		if (file_exists($csv_file) && is_file($csv_file)) {
			// process csv file	
			$conn->execute("UPDATE csv_files SET pid = ".$conn->qStr(getmypid())." WHERE id = ".$conn->qStr($csv['id'])." LIMIT 1");					
			$handle = fopen($csv_file, "r");
			if ($handle) {
				$index   = 0;
				$count   = 0;
				$added   = 0;
				$broken  = 0;				
				$duplicates  = 0;
				while ((($line = fgets($handle)) !== false) && ($count < $csv['maxrec'] || $csv['maxrec'] == 0 || $csv['maxrec'] == '')) {
					// process the line read
					if ($index >= $completed) {
						unset($video_data);
						$video_data = array();
						unset($video);
						$video = array();	
						$delimiter = find_delimiter($csv['format']);						
						$order = explode($delimiter, $csv['format']);						
						$video_data = explode($delimiter, $line);					
						foreach ($order as $k => $v) {
							$video[$v] = trim(preg_replace('/\s\s+/', ' ', $video_data[$k]));
							$video[$v] = trim($video[$v], '"');
							$video[$v] = str_replace('""', '"', $video[$v]);
						}
						$video['duration'] = duration_to_seconds($video['duration']);
						if (strpos($video['thumbs'],';') !== false) {
							$separator = ';';
						} else {
							$separator = ',';
						}
						$video['thumbs']   = explode($separator, $video['thumbs']);
						
						if (strpos($video['tags'],';') !== false && strpos($video['tags'],',') !== false)  {
							$video['tags'] = str_replace(';', ', ', $video['tags']);							
							$video['tags'] = str_replace(',', ', ', $video['tags']);							
						} elseif (strpos($video['tags'],';') !== false) {
							$video['tags'] = str_replace(';', ', ', $video['tags']);
						} else {
							$video['tags'] = str_replace(',', ', ', $video['tags']);
						}

						if ($video['tags'] == '') {
							$video['tags'] = title_to_tags($video['title']);
						}
						$video['user_id']  = $user_id;
						$video['status']   = $csv['status'];
						$video['index']    = $index+1;
						$video['csv_id']  = $csv['id'];
						$video['max_thumbs']  = $csv['max_thumbs'];					
						$video['check_duplicate']  = $csv['check_duplicate'];							
						if (!strpos($video['embed'], "iframe")) {
							$video['embed'] = '<iframe width="560" height="340" src="'.$video['embed'].'" frameborder="0" scrolling="no" allowfullscreen></iframe>';
						}
						switch (add_video($video, $csv['category'])) {
							case 1:
								$added++;
								break;
							case 2:
								$broken++;
								break;
							case 3:
								$duplicates++;
								break;
						}
						$count++;
					}
					$index++;
				}
				$csv['step'] == '1';				
				$messages[] = "Successfully processed <b>".$count."</b> record(s)!";
				$messages[] = "Added Videos: <b>".$added."</b>";
				if ($duplicates > 0) {
					$messages[] = "Duplicate Videos (Not Added): <b>".$duplicates."</b>";
				}
				if ($broken > 0) {
					$warnings[] = "<b>".$broken."</b> record(s) can't be processed!";
				}
				$conn->execute("UPDATE csv_files SET pid = '0' WHERE id = ".$conn->qStr($csv['id'])." LIMIT 1");	
				if (fgets($handle) == false) {
					$sql = "DELETE FROM csv_files WHERE id = '".$csv['id']."' LIMIT 1";
					$conn->execute($sql);					
				}
				fclose($handle);
			} else {
				// error opening the file.
				$errors[]	= 'Failed to load CSV file!';
			}
		} else {
			$errors[]	= 'Failed to load CSV file!';
		}

	} else {
		$csv['step'] = '3';
	}
}

if (isset($_POST['csv_import_stop'])) {
	$csv['id'] = $filter->get('csv_id');
	$conn->execute("UPDATE csv_files SET pid = '0' WHERE id = ".$conn->qStr($csv['id'])." LIMIT 1");
	$messages[]	= 'Importing has successfully stopped';
}

if ($csv['step'] == '1') {
	
	$sql = "SELECT * FROM csv_formats";
	$rs  = $conn->execute($sql);
	$csv['formats'] = $rs->getrows();
	
	$rs = $conn->execute("SELECT * FROM csv_files LIMIT 1");
	if ($conn->Affected_Rows()) {
		$csv['id']  	  = $rs->fields['id'];		
		$csv['url']	      = $rs->fields['url'];
		$csv['total']	  = $rs->fields['total'];
		$csv['completed'] = $rs->fields['completed'];
	}	
	
} elseif ($csv['step'] == '3') {
	
	$categories	= get_categories();
	if (!$csv['id']) {
		$csv['id']  = $filter->get('csv_id');
	}
	
	$rs = $conn->execute("SELECT * FROM csv_files WHERE id = '".$csv['id']."' LIMIT 1");
	if ($conn->Affected_Rows()) {
		$csv['total']	  = $rs->fields['total'];
		$csv['completed'] = $rs->fields['completed'];
	}	
}

function duration_to_seconds($duration)
{
	$duration = str_replace('s', '', $duration);
	$duration = str_replace('m', ':', $duration);
	$duration = str_replace('h', ':', $duration);
	$duration_parts = explode(':', $duration);
	
	if (substr_count($duration, ':') == 2) {
		$h = (int) $duration_parts[0];
		$m = (int) $duration_parts[1];
		$s = (int) $duration_parts[2];
	} elseif (substr_count($duration, ':') == 1) {
		$h = 0;
		$m = (int) $duration_parts[0];
		$s = (int) $duration_parts[1];
	} else {
		return $duration;
	}
	$seconds = ($h * 3600) + ($m * 60) + $s;
	return $seconds;
}

function title_to_tags ($title)
{
	$tags       = array();
	$tags_arr   = explode(' ', strtolower(prepare_string($title, false)));
	foreach ($tags_arr as $tag) {
		if (strlen($tag) >= 4) {
			$tags[] = $tag;
		}
	}
	return implode(' ', $tags);
}

function add_video($video, $category='')
{
	global $config, $conn, $width, $height, $image;

	$sql = "SELECT pid FROM csv_files WHERE id = ".$conn->qStr($video['csv_id'])." LIMIT 1";
	$rs  = $conn->execute($sql);
	$processing_pid = $rs->fields['pid'];
	$current_pid    = getmypid();
	if ($current_pid != $processing_pid) {
		exit;
	}
	
	if ($video['check_duplicate']) {
		$embed_str = str_replace (" ", "", $video['embed']);
		$embed_str = str_replace ("'", "\"", $embed_str);		
		if (preg_match('/src="(.*?)"/', $embed_str, $matches)) {
			$sql = "SELECT * FROM video WHERE embed_code LIKE '%".trim($conn->qStr($matches[1]), "'")."%' LIMIT 1";
			$conn->execute($sql);
			if ( $conn->Affected_Rows() > 0 ) {
				$conn->execute("UPDATE csv_files SET completed = '".$video['index']."' WHERE id = '".$video['csv_id']."' LIMIT 1");				
				return 3;
			}
		}
	}
	$active_thumb = 1;
	if ($category == '') {
		$category = match_category($video['category'], $video['title'], $video['description'], $video['tags']);
	}
	if (!$video['description']) {
		$video['description'] = '';
	}	
	$sql	= "INSERT INTO video
               SET UID = ".$video['user_id'].", 
                   title = ".$conn->qStr($video['title']).",  
                   description = ".$conn->qStr($video['description']).",  
                   keyword = ".$conn->qStr($video['tags']).",  
                   channel = ".$category.",  
                   duration = ".$video['duration'].",  
                   thumb = ".$active_thumb.",  
                   thumbs = ".(count($video['thumbs'])-1).",  				   
                   embed_code = ".$conn->qStr($video['embed']).",
				   addtime = ".time().",
				   adddate = '".date('Y-m-d')."',
				   vkey = '" .mt_rand(). "',
				   type = 'public',
				   active = '0'";
	$conn->execute($sql);
	if ($conn->Affected_Rows()) {

		$VID 		= $conn->insert_Id();
		$thumb_dir  = get_thumb_dir($VID);
        $count      = 1;
        $valid      = 0;
		
		$curl = new VCurl();
		if (mkdir($thumb_dir)) {
      		foreach ($video['thumbs'] as $thumb) {
				$dst = $thumb_dir.'/'.$count.'.jpg';
          		if ($curl->saveToFile2($thumb, $dst)) {
					if (filesize($dst) > 2000) {
					//-- Process Thumb - Aspect
						list($src_w, $src_h) = getimagesize($dst);
						
						$aspect     = $width / $height;
						$src_aspect = $src_w / $src_h;

						if ($aspect < $src_aspect) {
							$tmp_h = $height;
							$tmp_w = floor($tmp_h * $src_aspect);
							$image->process($dst, $dst, 'EXACT', $tmp_w, $tmp_h);
							$image->resize(true, true);
							$x = floor(($tmp_w - $width)/2);
							$y = 0;
							
						}
						else {
							$tmp_w = $width;
							$tmp_h = floor($tmp_w / $src_aspect);
							$image->process($dst, $dst, 'EXACT', $tmp_w, $tmp_h);
							$image->resize(true, true);
							$x = 0;
							$y = floor(($tmp_h - $height)/2);
						}
						
						$image->process($dst, $dst, 'EXACT', $width, $height);
						$image->crop($x, $y, $width, $height, true);				
					//-- End
						++$valid;
						++$count;
						if ($valid >= $video['max_thumbs']) {
							break;
						}
					}
					else {
						unlink($dst);
					}
				}
      		}
			$conn->execute("UPDATE csv_files SET completed = '".$video['index']."' WHERE id = '".$video['csv_id']."' LIMIT 1");
            if ($valid !== 0) {
				if( $valid > 3 ) {
					$active_thumb = 3;
				}				
				$vkey = substr(md5($VID),11,20);
				$sql  = "UPDATE video SET active = '".$video['status']."', thumbs = ".$valid.", thumb = ".$active_thumb.", vkey = '".$vkey."' WHERE VID = ".$VID." LIMIT 1";	
				$conn->execute($sql);				
				$sql  = "UPDATE channel SET total_videos = total_videos+1 WHERE CHID = " .$category. " LIMIT 1";
				$conn->execute($sql);
				$sql  = "UPDATE signup SET total_videos = total_videos+1, points = points+10 WHERE UID = " .$video['user_id']. " LIMIT 1";
				$conn->execute($sql);
				add_tags($video['tags']);
                return 1;
			} else {
				$sql = "DELETE FROM video WHERE VID = ".$VID." LIMIT 1";
				$conn->execute($sql);
				return 2;
			}			
		}
	} else {
		return 2;
	}
}

function match_category($name, $title, $description, $tags)
{	
	$categories	= get_categories();
	$defaut_category = reset($categories);

	foreach ($categories as $category) {
  		$category_name  = $category['name'];
        if ($name != '') {
      		if (stripos($category_name, $name) !== FALSE OR
          		stripos($name, $category_name) !== FALSE) {
                return $category['CHID'];
            }
        }
                
        if (stripos($title, $category_name) !== FALSE) {
            return $category['CHID'];
        }
                        
        if ($tags != '') {
      		if (stripos($tags, $category_name) !== FALSE) {
          	  return $category['CHID'];
            }
        }
                    
        if ($description != '') {
      		if (stripos($description, $category_name) !== FALSE) {
            return $category['CHID'];
            }
        }
    }
	
    return $defaut_category['CHID'];
}

function curl_contents($url) {
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$contents = curl_exec ($ch);
	//echo $contents;
	curl_close ($ch);
	return $contents;
}

function define_format($fields, $delimiter){
	$last_key = end(array_keys($fields));
	foreach ($fields as $key => $val) {
		if ($key == $last_key) {		
			$format = $format.$val;	
		} else {
			$format = $format.$val.$delimiter;
		}
	}
	return $format;
}

function check_format($formats, $findme) {
	foreach ($formats as $val) {
		if ($val == $findme ) {	
			return true;
		}
	}
	return false;
}

function find_delimiter($line) {
	if (strpos($line, '|')!== FALSE) {
		return '|';
	} elseif (strpos($line, ',')!== FALSE) {
		return ',';
	} elseif (strpos($line, ';')!== FALSE) {
		return ';';
	} elseif (strpos($line, '$')!== FALSE) {
		return '$';
	} elseif (strpos($line, '%')!== FALSE) {
		return '%';
	} elseif (strpos($line, '*')!== FALSE) {
		return '*';			
	} elseif (strpos($line, 'TAB')!== FALSE) {
		return 'TAB';
	} else {
		return FALSE;
	}
}

$plugin = 'jquery.add-videos-csv.js';

$smarty->assign('plugin', $plugin);
$smarty->assign('sites', $sites);
$smarty->assign('csv', $csv);
$smarty->assign('categories', $categories);
?>
