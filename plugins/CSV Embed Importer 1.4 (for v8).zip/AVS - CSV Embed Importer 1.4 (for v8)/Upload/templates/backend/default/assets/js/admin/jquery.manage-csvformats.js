function validateString(input,ml) {
	$(input).change(function(){
		if($(this).val().length < ml) {
			$(this).addClass('error');
		} else {
			$(this).removeClass('error');
		}
	});	
}

function hasErrors(input) {
	var err = false;
	$(input).each(function(){		
		if($(this).hasClass('error')) {
			err = true;
		}
	});
	return err;
}

$(document).ready(function(){
		
	$( "#reset_search" ).click(function() {
		document.getElementById('sort_items').innerText = 'ID';
		document.getElementById('sort').value = 'id';
		document.getElementById('order_items').innerText = 'Descending';
		document.getElementById('order').value = 'DESC';		
	});	


	//Ajax:

    $("body").on('click', "a[id*='delete_csvformat_']", function(event) {
        event.preventDefault();	
		var id = $(this).attr('id');
		var split = id.split('_');
		var csvformat_id = split[2];
		$('#delete__csvformat_' + csvformat_id).html('<i class="small-loader"></i>');
		$('#' + id).html('<i class="small-loader"></i>');
		$.post(base_url + '/ajax/admin_delete_csvformat', { csvformat_id: csvformat_id },
			function (response) {
				if (response.status) {
					Messenger().post({
						message: 'CSV Format <b>ID ' + csvformat_id + '</b>: Successfully deleted!',
						type: 'success'
					});
					$('#item-' + csvformat_id).fadeOut();
				} else {
					Messenger().post({
						message: 'CSV Format <b>ID ' + csvformat_id + '</b>: Delete failed!',
						type: 'error'
					});					
				}
		}, "json"); 
	});

	//Edit CSV Format
    $("body").on('click', "a[id*='edit_csvformat_']", function(event) {
        event.preventDefault();
		var id = $(this).attr('id');
		var split = id.split('_');
		var csvformat_id = split[2];
		$.post(base_url + '/ajax/admin_get_csvformat', { csvformat_id: csvformat_id },
			function (response) {
				if (response.status) {
					//Reset Errors
					$('.form-control').each(function(){
						$(this).removeClass('error');
					});				
					//Load CSV Format Data
					$('#edit-id-span').text(response.id);					
					$('#edit-id').val(response.id);
					$('#edit-name').val(response.name);
					$('#edit-format').val(response.format);
					$('#editModal').modal('show');					
				} else {
					Messenger().post({
						message: 'CSV Format <b>ID ' + csvformat_id + '</b>: Failed getting CSV Format details!',
						type: 'error'
					});
				}				
		}, "json"); 		
	});	

	//Reset
	$("body").on('click', "button[id='edit-reset']", function(event) {
        event.preventDefault();
		var csvformat_id = $('#edit-id').val();

		$.post(base_url + '/ajax/admin_get_csvformat', { csvformat_id: csvformat_id },
			function (response) {
				if (response.status) {
					//Reset Errors
					$('.form-control').each(function(){
						$(this).removeClass('error');
					});
					
					//Load CSV Format Data
					$('#edit-id-span').text(response.id);					
					$('#edit-id').val(response.id);
					$('#edit-name').val(response.name);
					$('#edit-format').val(response.format);
					
				} else {
					Messenger().post({
						message: 'CSV Format <b>ID ' + csvformat_id + '</b>: Failed getting CSV Format details!',
						type: 'error'
					});
				}				
		}, "json"); 					
	});	
	
	//Edit Save
	$("body").on('click', "button[id='edit-save']", function(event) {		
		event.preventDefault();
		var csvformat_id = $('#edit-id').val();
		if (!hasErrors("input[id*='edit-']") && !hasErrors("textarea[id*='edit-']")) {
			//save code
			$('#edit_csvformat_' + csvformat_id).html('<i class="small-loader"></i>');			
			var csvformatData = {
				id 		     : $('#edit-id').val(),
				name 		 : $('#edit-name').val(),
				format   	 : $('#edit-format').val(),
			};
			
			$.post(base_url + '/ajax/admin_save_csvformat', { data: csvformatData },
				function (response) {					
					$('#editModal').modal('hide');
					if (response.status) {
						Messenger().post({
							message: 'CSV Format <b>ID ' + csvformat_id + '</b>: Successfully updated!',
							type: 'success'
						});
						$('#name-' + csvformat_id).text(csvformatData.name);
						$('#format-' + csvformat_id).html('<b>'+csvformatData.format+'</b>');				
					} else {
						Messenger().post({
							message: 'CSV Format <b>ID ' + csvformat_id + '</b>: Incorrect CSV Format / Name or Failed updating!',
							type: 'error'
						});
					}
					$('#edit_csvformat_' + csvformat_id).html('<i class="fa fa-pencil"></i>');	
			}, "json");			
		}
		
	});
	
	//Validate
	validateString('#edit-name',1);
	validateString('#edit-format',36);
	
});