$(document).ready(function(){

	$("#format_id").select2();
	$("#format_id").select2 ('container').find ('.select2-search').addClass ('hidden');

	$(function () {
		$("textarea[name^='field_content_']" ).each(function () {
			this.style.height = (this.scrollHeight)+'px';
		});
	});

	$("select[id^='field_']" ).select2();
	$("select[id^='field_']" ).select2 ('container').find ('.select2-search').addClass ('hidden');

    $("body").on('click', "input[id='csv_import_start']", function(event) {
        //event.preventDefault();
		var csvmaxrec = $("#maxrec").val();
		if (csvmaxrec == '' || csvmaxrec == 0) {
			var csvrecords = csvtotal - csvcompleted;
		} else {
			var csvrecords = Math.min(csvmaxrec, (csvtotal - csvcompleted));
		}		
		$("#import_progress_container").show();
		$("#csv_import_form").submit();
		$("#csv_import_start").hide();
		$("#csv_import_stop").show();
		var intervalCSV = window.setInterval(function(){
			$.post(base_url + '/ajax/admin_check_csvimport', { id: csvid },
			function (response) {
				if (response.status) {
					var newcompleted = response.completed - csvcompleted;
					var progress = Math.ceil((100 * newcompleted) / csvrecords);
					document.getElementById("import_progress").style.width = progress + "%";
					$("#csv_completed").text(response.completed);
				}				
			}, "json"); 
		}, 500);
    });	
	
    $("body").on('click', "a[id='csv_import_stop']", function(event) {
        //event.preventDefault();
		$("#csv_import_form").submit();
		clearInterval(intervalCSV);
    });		
	
	var percentSlider = $('#max_thumbs').slider();
});