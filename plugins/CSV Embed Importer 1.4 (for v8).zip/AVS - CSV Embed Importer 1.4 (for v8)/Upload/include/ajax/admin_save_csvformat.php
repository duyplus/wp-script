<?php
defined('_VALID') or die('Restricted Access!');

require $config['BASE_DIR']. '/classes/filter.class.php';
require $config['BASE_DIR']. '/include/compat/json.php';
require $config['BASE_DIR']. '/include/adodb/adodb.inc.php';
require $config['BASE_DIR']. '/include/dbconn.php';

$response = array('status' => 0);

$data = (array) $_POST['data'];

$fid          = trim($data['id']);
$name         = trim($data['name']);
$csvformat    = trim($data['format']);

settype($fid, 'integer');


if ( $name == '' ) {
	$errors[] = 'CSV format name field cannot be blank!';
} else {
	$sql        = "SELECT id FROM csv_formats WHERE name = " .$conn->qStr($name). " AND id != " .$conn->qStr($fid). " LIMIT 1";
	$conn->execute($sql);
	if ( $conn->Affected_Rows() > 0 ) {
		$errors[]   = 'CSV format name \'' .htmlspecialchars($csvformat['name'], ENT_QUOTES, 'UTF-8'). ' is already used. Please choose another name!';
	}
}

if (strpos($csvformat, '|')!== FALSE) {
	$delimiter = '|';
} elseif (strpos($csvformat, ',')!== FALSE) {
	$delimiter = ',';
} elseif (strpos($csvformat, ';')!== FALSE) {
	$delimiter = ';';
} elseif (strpos($csvformat, '$')!== FALSE) {
	$delimiter = '$';
} elseif (strpos($csvformat, '%')!== FALSE) {
	$delimiter = '%';
} elseif (strpos($csvformat, '*')!== FALSE) {
	$delimiter = '*';			
} elseif (strpos($csvformat, 'TAB')!== FALSE) {
	$delimiter = 'TAB';
} else {
	$errors[] = 'Field delimiter is missing! Allowed delimiters: <b>| , ; $ % * TAB</b>';	
}

$parts = explode($delimiter, $csvformat);
$format = '';
foreach ($parts as $k => $v) {
	$value = strtolower($v);
	if (strpos($value, 'embed') !== false) {
		$format = $format.$delimiter.'embed';
	} elseif (strpos($value, 'title') !== false) {
		$format = $format.$delimiter.'title';
	} elseif (strpos($value, 'thumb') !== false) {
		$format = $format.$delimiter.'thumbs';
	} elseif (strpos($value, 'category') !== false) {
		$format = $format.$delimiter.'category';
	} elseif (strpos($value, 'channel') !== false) {
		$format = $format.$delimiter.'category';				
	} elseif (strpos($value, 'duration') !== false) {
		$format = $format.$delimiter.'duration';			
	} elseif (strpos($value, 'length') !== false) {
		$format = $format.$delimiter.'duration';
	} elseif (strpos($value, 'tag') !== false) {
		$format = $format.$delimiter.'tags';
	} elseif (strpos($value, 'description') !== false) {
		$format = $format.$delimiter.'description';				
	} else {
		$format = $format.$delimiter.'other';
	}
}
$format= ltrim($format, $delimiter);

if (strpos($format, 'embed') === false)    $errors[] = '<b>embed</b> field is required!';
if (strpos($format, 'thumbs') === false)   $errors[] = '<b>thumbs</b> field is required!';
if (strpos($format, 'title') === false)    $errors[] = '<b>title</b> field is required!';
if (strpos($format, 'category') === false) $errors[] = '<b>category</b> field is required!';
if (strpos($format, 'duration') === false) $errors[] = '<b>duration</b> field is required!';


if ( !$errors ) {
	$sql = "UPDATE csv_formats SET name = " .$conn->qStr($name). ", format = " .$conn->qStr($format). " WHERE id = " .$conn->qStr($fid). "";
	$conn->execute($sql);
	$response['status'] = 1;
}


echo json_encode($response);
die();
?>
