<?php
defined('_VALID') or die('Restricted Access!');

require $config['BASE_DIR']. '/classes/filter.class.php';
require $config['BASE_DIR']. '/include/compat/json.php';
require $config['BASE_DIR']. '/include/adodb/adodb.inc.php';
require $config['BASE_DIR']. '/include/dbconn.php';
$response = array('status' => 0);

$filter  = new VFilter();
$id      = $filter->get('id', 'INTEGER');
$sql     = "SELECT * FROM csv_files WHERE id = " .$conn->qStr($id). " LIMIT 1";
$rs = $conn->execute($sql);

if ( $conn->Affected_Rows() == 1 ) {
	$csvformat = $rs->getrows();
	$csvformat = $csvformat[0];
	foreach ($csvformat as $key=>$value) {
		$response[$key] = $value;
	}		
	$response['status'] = 1;
}

echo json_encode($response);
die();
?>
